var GOFLY_CONFIG={
    "SHOW_WECHAT":false,//是否展示微信二维码
    "SHOW_OFFLINE_PAGE":false,//是否展示离线页面
    "WECHAT_QR_URL":"http://wechat.sopans.com/api/wechat/showQrImg",
}