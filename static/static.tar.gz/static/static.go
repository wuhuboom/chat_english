package static

import "embed"

//go:embed templates
var TemplatesEmbed embed.FS
